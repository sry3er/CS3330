#include <stdlib.h>
#include <immintrin.h>  // for future use of SSE

#include "sum.h"
/* sum.h defines unsigned short to be an alias for unsigned short.
 * It also defines function_type.
 */

/* reference implementation in C */
unsigned short sum_C(long size, unsigned short * a) {
    unsigned short sum = 0;
    for (int i = 0; i < size; ++i) {
        sum += a[i];
    }
    return sum;
}

/* implementations in assembly */
extern unsigned short sum_naive(long, unsigned short *);
extern unsigned short sum_gcc5_O3(long, unsigned short *);
extern unsigned short sum_gcc5_O2(long, unsigned short *);
extern unsigned short sum_clang5_O(long, unsigned short *);
extern unsigned short sum_gcc7_O3(long, unsigned short *);
// add prototypes here!

/* This is the list of functions to test */
function_info functions[] = {
    {sum_C, "sum_C: naive C compiled on this machine with settings in Makefile"},
    {sum_naive, "sum_naive: naive ASM"},
    {sum_gcc5_O2, "sum_gcc5_O2: naive C compiled with GCC5 -O2"},
    {sum_gcc5_O3, "sum_gcc5_O3: naive C compiled with GCC5 -O3"},
    {sum_clang5_O, "sum_clang5_O: naive C compiled with clang 5.0 -O -msse4.2"},
    {sum_gcc7_O3, "sum_gcc7_O3: naive C compiled with GCC7 -O3 -msse4.2"}, 
    // add entries here!
    {NULL, NULL},
};
